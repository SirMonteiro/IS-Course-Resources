#include <stdio.h>

int main() {
    printf("3.14159\n");
    printf("%f\n",3.14159);
    printf("%f\n",3*3.14159);
    printf("%i\n",1+2+3+4+5);
    printf("%i\n",9/(3*3));
    return 0;
}