#include <stdio.h>

int main() {
    int meuNumeroUSP = 123456789;
    printf("meuNumeroUSP\n");
    printf("%i\n",meuNumeroUSP);
    printf("%i\n",meuNumeroUSP / 5);
    printf("%i\n",meuNumeroUSP % 5);
    return 0;
}