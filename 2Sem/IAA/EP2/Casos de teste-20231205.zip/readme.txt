Para cenário 1 e período de atualização = 14h, arquivos: 1_entrada.txt e 1_saida.txt

Para cenário 2 e período de atualização = 20h, arquivos: 2_entrada.txt e 2_saida.txt

Para cenário 1 e período de atualização = 20h (note que somente 19h serão aproveitadas para atualizações), arquivos: 3_entrada.txt e 3_saida.txt

Para cenário 2 e período de atualização = 20h, arquivos: 4_entrada.txt e 4_saida.txt
