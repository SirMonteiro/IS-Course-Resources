#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int tam = 100;
    tam += 1;

    //char nome[tam] = "Ariane Machado Lima";
    char nome[30] = "Ariane Machado Lima";
    //char nome2[10] = "Ariane Machado Lima";

    printf("Tamanho: %ld\n", strlen(nome)); 

    /* nome = "Ariane Machado Lima"; 
    printf("Nome: %s\n", nome); */

    double vetor[argc];
    vetor[0] = atof(argv[1]);
    vetor[1] = atof(argv[2]);
 
    printf("%f %f\n", vetor[0], vetor[1]); 

    float temperaturasDaSemana[7] = {20, 20.4, 20.6, 19, 17.8, 18.9, 24.1};

}