#include<stdio.h>
#include<stdbool.h>

int main()
{
    bool x = 10 > 18;  /* false, que significa 0 se imprimir como inteiro*/
    printf("%d ou ",x);
    printf("%s", x ? "true" : "false");
    bool y = true;
    printf("\n%d ou ",y);
    printf("%s", y ? "true" : "false");
    printf("\nTamanho do bool em bytes é %ld\n",sizeof(bool));
    return 0;
}