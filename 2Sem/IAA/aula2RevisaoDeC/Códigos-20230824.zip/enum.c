#include<stdio.h>
int main()
{
    typedef enum {DOMINGO = 1, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO} DiaDaSemana;
    //enum {DOMINGO = 1, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO};

    DiaDaSemana hoje = SEXTA;

    float temperaturasDaSemana[7]; 
    temperaturasDaSemana[DOMINGO] = 28.5;
    temperaturasDaSemana[SEGUNDA] = 30.1;  
    temperaturasDaSemana[2] = 0.5; 
    temperaturasDaSemana[3] = 3.1; 
    temperaturasDaSemana[hoje] = 19.0;


    printf("%.1f, %.1f\n", temperaturasDaSemana[hoje], temperaturasDaSemana[TERCA] );

} 
