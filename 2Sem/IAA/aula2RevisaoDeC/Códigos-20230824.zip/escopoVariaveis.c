#include <stdio.h>

int dia = 27;

int main()
{
  printf("Hoje é %d\n", dia);

  return 0;
}

