#include <stdio.h>

void funcaoMisteriosa(int n, int* array){
  for (int i = 0; i < n; i++){
    (*array)++;
    array++;
  }
} 

int main(void){
  int v[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
  funcaoMisteriosa(10, v);
  for (int i = 0; i < 10; i++)
    printf("%d ", v[i]);
  printf("\n");
}