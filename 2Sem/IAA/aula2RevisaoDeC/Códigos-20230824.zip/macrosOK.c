#include <stdio.h>

#define PI 3
#define QUAD(x) (x) * (x)

int main()
{
    printf("Valor de pi = PI: %d\n", PI);

    int piQuadrado = QUAD(PI);
    int doisMaisPiQuadrado = QUAD(2+PI);
    printf("Valor de piQ = %d e (2+pi)Q = %d\n", piQuadrado, doisMaisPiQuadrado);

    return 0;
}