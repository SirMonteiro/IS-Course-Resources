#include<stdio.h>
int main()
{
    struct {
        long nrUSP;
        float notaEP1;
        //float notaEP2;
        float mediaProvinhas;
    } aluno1;

    aluno1.nrUSP = 555555;
    aluno1.notaEP1 = 9.9;
    printf("\nNota do aluno %ld é %f\n", aluno1.nrUSP, aluno1.notaEP1);

    printf("\nTamanho em bytes do long é %ld\n",sizeof(long));
    printf("\nTamanho em bytes do float é %ld\n",sizeof(float));
    printf("\nTamanho em bytes da estrutura é %ld\n",sizeof(aluno1));
    
    return 0;
}



