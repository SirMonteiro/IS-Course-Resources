#include<stdio.h>
int main()
{
    struct aluno{
        long nrUSP;
        float notaEP1;
        float notaEP2;
        float mediaProvinhas;
    };

    struct aluno aluno1, aluno2;

    aluno1.nrUSP = 555555;
    aluno1.notaEP1 = 9.9;
    printf("\nNota do aluno %ld é %.1f\n", aluno1.nrUSP, aluno1.notaEP1);

    aluno2.nrUSP = 6666666;
    aluno2.notaEP1 = 8.88;
    printf("\nNota do aluno %ld é %.1f\n", aluno2.nrUSP, aluno2.notaEP1);

    printf("\nTamanho em bytes do long é %ld\n",sizeof(long));
    printf("\nTamanho em bytes do float é %ld\n",sizeof(float));
    printf("\nTamanho em bytes da estrutura é %ld\n",sizeof(struct aluno));
    
    return 0;
}