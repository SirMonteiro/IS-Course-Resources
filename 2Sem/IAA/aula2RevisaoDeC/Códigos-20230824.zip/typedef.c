#include<stdio.h>
int main()
{
    typedef struct {
        long nrUSP;
        float notaEP1;
        float notaEP2;
        float mediaProvinhas;
    } Aluno;

    Aluno aluno1, aluno2, aluno3;

    aluno1.nrUSP = 555555;
    aluno1.notaEP1 = 9.9;
    printf("\nNota do aluno %ld é %.1f\n", aluno1.nrUSP, aluno1.notaEP1);

    printf("\nTamanho em bytes do long é %ld\n",sizeof(long));
    printf("\nTamanho em bytes do float é %ld\n",sizeof(float));
    printf("\nTamanho em bytes da estrutura é %ld\n",sizeof(Aluno));
    
    return 0;
}