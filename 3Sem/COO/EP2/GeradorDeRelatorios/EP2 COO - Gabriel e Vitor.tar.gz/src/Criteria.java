public interface Criteria {
  public boolean compare(Produto p1, Produto p2);
}
