public interface Filter {
  public boolean filter(Produto p, String argFilter);
}
