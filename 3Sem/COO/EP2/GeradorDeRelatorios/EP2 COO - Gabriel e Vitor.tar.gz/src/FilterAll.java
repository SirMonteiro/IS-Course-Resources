public class FilterAll implements Filter {
  public boolean filter(Produto p, String argFilter) {
    return true;
  }
}
