import java.io.PrintWriter;

public interface Format {
  void format(PrintWriter out, Produto p);
}
