import java.util.List;

public interface Sort {
  public void ordena(int ini, int fim, List<Produto> produtos, Criteria criterio);
}
